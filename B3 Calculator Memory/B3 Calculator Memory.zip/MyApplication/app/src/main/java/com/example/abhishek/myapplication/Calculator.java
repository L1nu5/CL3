package com.example.abhishek.myapplication;

/**
 * Created by lenovo on 15/4/17.
 */

public class Calculator {
    public Calculator(){

    }

    public Double add (Double a, Double b){
        return a+b;
    }

    public Double sub (Double a, Double b){
        return a-b;
    }
    public Double mul (Double a, Double b){
        return a*b;
    }
    public Double div (Double a, Double b){
        return a/b;
    }
    public Double sin (Double a){
        return Math.sin(a);
    }
    public Double cos(Double a){
        return Math.cos(a);
    }
    public Double tan (Double a){
        return Math.tan(a);
    }

    public Double sqrt (Double a){
        return Math.sqrt(a);
    }


}
